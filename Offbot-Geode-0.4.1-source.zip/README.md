# Offbot 0.4.1 — código fuente nativo de Geode

**Este ZIP contiene código fuente, no un paquete `.geode` compilado.** No se ha podido compilar contra el SDK ni probar dentro de Geometry Dash en un teléfono en este entorno.

## Incluye
- Nombre y metadatos Offbot.
- Punto de entrada en `PauseLayer::customSetup`; no se añade botón al menú principal.
- Panel compacto con controles Record, Stop Rec, Save, Load, Play, Stop Play y Close.
- Captura de eventos mediante el hook de `GJBaseGameLayer::handleButton(bool, int, bool)` y avance mediante `PlayLayer::postUpdate(float)`.
- Guardado/carga de `last-macro.gdc` en el directorio de guardado del mod.
- Flujo de GitHub Actions para Android32 y Android64.

## Límites que siguen siendo importantes
- Es una versión de fuente en desarrollo, no una versión final validada.
- El panel y las firmas aún necesitan confirmación mediante compilación y prueba real.
- La reproducción se sincroniza con llamadas de actualización del juego; la precisión no se ha medido.
- La cronología de eventos no se borra cuando se reinicia el contador de intento, pero la reproducción **no reconstruye de forma determinista** la colocación/restauración de checkpoints ni los múltiples intentos de práctica. No usar todavía para afirmar compatibilidad fiable con checkpoints.
- No incluye bot automático.
- No se ha confirmado que Android32/Android64 generen `.geode` instalables.

## Formato de macro
`GDCONTROL_MACRO 1`, seguido de filas `frame button down player1`. El contador es una secuencia de actualizaciones propia del mod, no el contador de intento de Geometry Dash.

## Compilar desde Android
1. Extrae el ZIP en el teléfono.
2. Sube el contenido de la carpeta al repositorio `oplimbo945-eng/Bot-test1`, rama `main`, conservando `.github/workflows/android.yml`.
3. En GitHub abre **Actions** y ejecuta **Build Offbot Android**.
4. Descarga los artefactos `Offbot-Android32` y `Offbot-Android64` únicamente si los trabajos finalizan correctamente.
5. Si falla, comparte el log completo para corregir el error concreto.

Un CI correcto confirma compilación y empaquetado para ese objetivo; no demuestra que el menú o la reproducción funcionen en el juego. La prueba en el teléfono sigue siendo obligatoria.

## SDK objetivo
Se fija Geode `v5.11.2` y Geometry Dash `2.2081`. Esta selección es intencionada, pero la compatibilidad de este código no está confirmada hasta que compile y se pruebe.

## Referencias oficiales
- https://github.com/geode-sdk/bindings/blob/main/bindings/2.2081/GeometryDash.bro
- https://github.com/geode-sdk/example-mod
- https://github.com/geode-sdk/build-geode-mod
