# Offbot — cronología de práctica

El contador de sesión del prototipo no se reinicia por decisión del mod cuando cambia el contador de intento. Esto evita borrar silenciosamente los eventos anteriores, pero no hace determinista la reproducción de una sesión de práctica.

Para completar esa función se deben registrar eventos explícitos de checkpoint, restauración, muerte y reinicio, y comprobar que la reproducción no duplica reinicios ni aplica entradas a un estado de nivel diferente. Hasta entonces, las macros con varios intentos/checkpoints se consideran datos archivados, no una reproducción fiable.
