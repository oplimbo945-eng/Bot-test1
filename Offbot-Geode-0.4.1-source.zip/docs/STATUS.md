# Offbot 0.4.1 — estado veraz

- [x] Nombre Offbot y metadatos actualizados.
- [x] ZIP de fuente validable y archivos esenciales presentes.
- [x] UI de pausa y callbacks escritos en el código.
- [x] Código de captura, guardado/carga y reproducción presente como prototipo.
- [x] Matriz de GitHub Actions para Android32 y Android64.
- [ ] Compilación confirmada contra Geode v5.11.2.
- [ ] Artefactos `.geode` generados y revisados.
- [ ] Botón/panel probado en Geometry Dash 2.2081 Android.
- [ ] Grabación y reproducción probadas en un nivel real.
- [ ] Precisión temporal medida.
- [ ] Reproducción de práctica con checkpoints y reinicios implementada y probada de extremo a extremo.
- [ ] Bot automático.

No presentar como terminado hasta resolver las tareas pendientes.
