#include <Geode/Geode.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace geode::prelude;

namespace gdcontrol {
    struct InputEvent {
        std::uint64_t frame = 0;
        int button = 0;
        bool down = false;
        bool player1 = true;
    };

    // One session-wide frame clock. It is deliberately independent of GD's
    // attempt/frame counters, which can reset when practice checkpoints restore.
    class MacroEngine {
    public:
        static MacroEngine& get() {
            static MacroEngine instance;
            return instance;
        }

        void beginRecording() {
            m_events.clear();
            m_frame = 0;
            m_playIndex = 0;
            m_recording = true;
            m_playing = false;
            m_injected = false;
            m_status = "Recording (session timeline)";
            log::info("Offbot: macro recording started");
        }

        void stopRecording() {
            if (m_recording) {
                m_recording = false;
                m_status = fmt::format("Recording stopped: {} events", m_events.size());
                log::info("Offbot: recording stopped with {} events", m_events.size());
            }
        }

        bool save() {
            stopRecording();
            auto path = Mod::get()->getSaveDir() / "last-macro.gdc";
            std::ofstream out(path.string(), std::ios::binary | std::ios::trunc);
            if (!out) {
                m_status = "Save failed: cannot open macro file";
                log::error("Offbot: could not write {}", path.string());
                return false;
            }
            out << "GDCONTROL_MACRO 1\n";
            out << "# frame button down player1; frame is session-wide update count\n";
            for (auto const& event : m_events) {
                out << event.frame << ' ' << event.button << ' '
                    << (event.down ? 1 : 0) << ' ' << (event.player1 ? 1 : 0) << '\n';
            }
            out.flush();
            if (!out) {
                m_status = "Save failed while writing";
                return false;
            }
            m_status = fmt::format("Saved {} events", m_events.size());
            log::info("Offbot: saved {} events to {}", m_events.size(), path.string());
            return true;
        }

        bool load() {
            auto path = Mod::get()->getSaveDir() / "last-macro.gdc";
            std::ifstream in(path.string(), std::ios::binary);
            if (!in) {
                m_status = "Load failed: no saved macro";
                return false;
            }
            std::string header;
            std::getline(in, header);
            if (header != "GDCONTROL_MACRO 1") {
                m_status = "Load failed: unsupported file format";
                return false;
            }
            std::vector<InputEvent> parsed;
            std::string line;
            while (std::getline(in, line)) {
                if (line.empty() || line[0] == '#') continue;
                InputEvent event;
                int down = 0;
                int player1 = 0;
                std::istringstream row(line);
                if (!(row >> event.frame >> event.button >> down >> player1)) {
                    m_status = "Load failed: malformed event";
                    return false;
                }
                if (event.button < 0 || event.button > 16 || (down != 0 && down != 1) ||
                    (player1 != 0 && player1 != 1)) {
                    m_status = "Load failed: event values out of range";
                    return false;
                }
                event.down = down != 0;
                event.player1 = player1 != 0;
                parsed.push_back(event);
            }
            if (in.bad()) {
                m_status = "Load failed while reading";
                return false;
            }
            if (!std::is_sorted(parsed.begin(), parsed.end(), [](auto const& a, auto const& b) {
                    return a.frame < b.frame;
                })) {
                m_status = "Load failed: events are not chronological";
                return false;
            }
            m_events = std::move(parsed);
            m_recording = false;
            m_playing = false;
            m_frame = 0;
            m_playIndex = 0;
            m_status = fmt::format("Loaded {} events", m_events.size());
            log::info("Offbot: loaded {} events from {}", m_events.size(), path.string());
            return true;
        }

        bool beginPlayback() {
            if (m_events.empty()) {
                m_status = "Playback unavailable: macro is empty";
                return false;
            }
            m_recording = false;
            m_playing = true;
            m_frame = 0;
            m_playIndex = 0;
            m_status = fmt::format("Playing {} events", m_events.size());
            log::info("Offbot: playback started ({} events)", m_events.size());
            return true;
        }

        void stopPlayback() {
            if (m_playing) {
                m_playing = false;
                m_status = "Playback stopped";
                log::info("Offbot: playback stopped");
            }
        }

        void capture(bool down, int button, bool player1) {
            if (!m_recording || m_injected) return;
            m_events.push_back({m_frame, button, down, player1});
        }

        void advance(PlayLayer* layer) {
            if (!m_recording && !m_playing) return;
            ++m_frame;
            if (!m_playing || !layer) return;

            // Use GD's bound input handler, not synthetic touch events. The hook
            // guard prevents injected events from being recorded a second time.
            while (m_playIndex < m_events.size() && m_events[m_playIndex].frame <= m_frame) {
                auto const event = m_events[m_playIndex++];
                m_injected = true;
                layer->handleButton(event.down, event.button, event.player1);
                m_injected = false;
            }
            if (m_playIndex >= m_events.size()) {
                m_playing = false;
                m_status = "Playback finished";
                log::info("Offbot: playback finished");
            }
        }

        bool isInjecting() const { return m_injected; }
        bool isRecording() const { return m_recording; }
        bool isPlaying() const { return m_playing; }
        std::size_t eventCount() const { return m_events.size(); }
        std::string const& status() const { return m_status; }

    private:
        std::vector<InputEvent> m_events;
        std::uint64_t m_frame = 0;
        std::size_t m_playIndex = 0;
        bool m_recording = false;
        bool m_playing = false;
        bool m_injected = false;
        std::string m_status = "Ready";
    };
}

using gdcontrol::MacroEngine;

class $modify(GDControlPauseLayer, PauseLayer) {
    CCMenuItemSpriteExtra* makeTextButton(char const* text, SEL_MenuHandler callback) {
        auto* label = CCLabelBMFont::create(text, "bigFont.fnt");
        if (!label) return nullptr;
        label->setScale(0.42f);
        return CCMenuItemSpriteExtra::create(label, this, callback);
    }

    void customSetup() {
        PauseLayer::customSetup();
        auto winSize = CCDirector::sharedDirector()->getWinSize();

        auto* openMenu = CCMenu::create();
        auto* openButton = makeTextButton("OFFBOT", menu_selector(GDControlPauseLayer::onGDControl));
        if (!openMenu || !openButton) {
            log::warn("Offbot: pause menu button creation failed");
            return;
        }
        openButton->setID("gdcontrol-open-button"_spr);
        openMenu->addChild(openButton);
        openMenu->setPosition({winSize.width - 68.f, winSize.height * 0.52f});
        this->addChild(openMenu, 100);

        auto* panel = CCLayerColor::create(ccc4(0, 0, 0, 220), 320.f, 220.f);
        auto* controlMenu = CCMenu::create();
        if (!panel || !controlMenu) {
            log::warn("Offbot: control panel creation failed");
            return;
        }
        panel->setID("gdcontrol-panel"_spr);
        panel->setPosition({(winSize.width - 320.f) / 2.f, (winSize.height - 220.f) / 2.f});
        controlMenu->setPosition({0.f, 0.f});
        panel->addChild(controlMenu);

        // Compact native text branding. This deliberately uses the game's font
        // atlas so no external texture or Android-specific asset path is needed.
        auto* title = CCLabelBMFont::create("OFFBOT  |  MACRO MANAGER", "bigFont.fnt");
        if (title) {
            title->setScale(0.43f);
            title->setPosition({160.f, 202.f});
            title->setColor({0, 220, 255});
            panel->addChild(title, 2);
        }
        auto* hint = CCLabelBMFont::create("NORMAL / PRACTICE - SOURCE BUILD", "bigFont.fnt");
        if (hint) {
            hint->setScale(0.25f);
            hint->setPosition({160.f, 16.f});
            hint->setColor({190, 205, 220});
            panel->addChild(hint, 2);
        }
        this->addChild(panel, 1000);

        auto add = [this, controlMenu](char const* text, SEL_MenuHandler callback, float x, float y) {
            auto* item = makeTextButton(text, callback);
            if (item) {
                item->setPosition({x, y});
                controlMenu->addChild(item);
            }
        };
        add("RECORD", menu_selector(GDControlPauseLayer::onRecord), 82.f, 178.f);
        add("SAVE", menu_selector(GDControlPauseLayer::onSave), 238.f, 178.f);
        add("STOP REC", menu_selector(GDControlPauseLayer::onStopRecord), 82.f, 132.f);
        add("LOAD", menu_selector(GDControlPauseLayer::onLoad), 238.f, 132.f);
        add("PLAY", menu_selector(GDControlPauseLayer::onPlay), 82.f, 86.f);
        add("STOP PLAY", menu_selector(GDControlPauseLayer::onStopPlay), 238.f, 86.f);
        add("CLOSE", menu_selector(GDControlPauseLayer::onClosePanel), 160.f, 35.f);
        panel->setVisible(false);
    }

    void onGDControl(CCObject*) {
        if (auto* panel = this->getChildByID("gdcontrol-panel"_spr)) panel->setVisible(!panel->isVisible());
    }

    void showStatus(char const* title) {
        auto const& status = MacroEngine::get().status();
        FLAlertLayer::create(title, status.c_str(), "OK")->show();
    }

    void onRecord(CCObject*) {
        MacroEngine::get().beginRecording();
        showStatus("Offbot");
    }
    void onStopRecord(CCObject*) {
        MacroEngine::get().stopRecording();
        showStatus("Offbot");
    }
    void onSave(CCObject*) {
        MacroEngine::get().save();
        showStatus("Offbot");
    }
    void onLoad(CCObject*) {
        MacroEngine::get().load();
        showStatus("Offbot");
    }
    void onPlay(CCObject*) {
        MacroEngine::get().beginPlayback();
        showStatus("Offbot");
    }
    void onStopPlay(CCObject*) {
        MacroEngine::get().stopPlayback();
        showStatus("Offbot");
    }
    void onClosePanel(CCObject*) {
        if (auto* panel = this->getChildByID("gdcontrol-panel"_spr)) panel->setVisible(false);
    }
};

class $modify(GDControlInputHook, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
        if (PlayLayer::get() == this && !MacroEngine::get().isInjecting()) {
            MacroEngine::get().capture(down, button, isPlayer1);
        }
    }
};

class $modify(GDControlPlayLayer, PlayLayer) {
    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        if (PlayLayer::get() == this) MacroEngine::get().advance(this);
    }
};

$execute {
    log::info("Offbot 0.4.1 loaded; pause-only UI and session-timeline macro engine initialized.");
}
