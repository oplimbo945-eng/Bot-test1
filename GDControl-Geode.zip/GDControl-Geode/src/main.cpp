#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <filesystem>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace geode::prelude;

namespace gdcontrol {
    struct Event {
        int frame = 0;
        int button = 0;
        bool down = false;
        bool player1 = true;
        bool dual = false;
    };

    enum class Mode { Idle, Recording, Playing };
    static Mode mode = Mode::Idle;
    static std::vector<Event> events;
    static int frame = 0;
    static size_t nextEvent = 0;
    static bool replaying = false;

    static std::filesystem::path macroPath() {
        return Mod::get()->getSaveDir() / "last-macro.gdc";
    }

    static bool saveMacro() {
        std::error_code ec;
        std::filesystem::create_directories(Mod::get()->getSaveDir(), ec);
        std::ofstream out(macroPath(), std::ios::trunc);
        if (!out) return false;
        out << "# GDControl macro v1\n";
        out << "# frame,button,down,player1,dual\n";
        for (auto const& e : events) {
            out << e.frame << ',' << e.button << ',' << (e.down ? 1 : 0) << ','
                << (e.player1 ? 1 : 0) << ',' << (e.dual ? 1 : 0) << '\n';
        }
        return static_cast<bool>(out);
    }

    static bool loadMacro() {
        std::ifstream in(macroPath());
        if (!in) return false;
        std::vector<Event> loaded;
        std::string line;
        while (std::getline(in, line)) {
            if (line.empty() || line[0] == '#') continue;
            std::replace(line.begin(), line.end(), ',', ' ');
            std::istringstream row(line);
            Event e;
            int down = 0, player1 = 1, dual = 0;
            if (!(row >> e.frame >> e.button >> down >> player1 >> dual)) continue;
            if (e.frame < 0 || e.button < 0 || e.button > 16) continue;
            e.down = down != 0; e.player1 = player1 != 0; e.dual = dual != 0;
            loaded.push_back(e);
        }
        if (loaded.empty()) return false;
        std::stable_sort(loaded.begin(), loaded.end(), [](auto const& a, auto const& b) { return a.frame < b.frame; });
        events = std::move(loaded);
        return true;
    }

    static void stop() {
        if (mode == Mode::Recording) {
            if (saveMacro()) log::info("GD Control: saved {} input events", events.size());
            else log::error("GD Control: couldn't save macro");
        }
        mode = Mode::Idle;
        nextEvent = 0;
        replaying = false;
    }

    static void cycleMode() {
        if (mode == Mode::Recording) {
            stop();
            Notification::create("GD Control: macro saved", NotificationIcon::Success)->show();
            return;
        }
        if (mode == Mode::Playing) {
            stop();
            Notification::create("GD Control: playback stopped", NotificationIcon::Info)->show();
            return;
        }
        if (loadMacro()) {
            mode = Mode::Playing;
            frame = 0;
            nextEvent = 0;
            Notification::create("GD Control: playback starts on level", NotificationIcon::Info)->show();
            return;
        }
        events.clear();
        frame = 0;
        mode = Mode::Recording;
        Notification::create("GD Control: recording inputs", NotificationIcon::Info)->show();
    }
}

class $modify(GDControlMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        auto menu = this->getChildByID("bottom-menu");
        if (!menu) menu = this->getChildByID("main-menu");
        if (menu) {
            auto sprite = CCSprite::createWithSpriteFrameName("GJ_playBtn2_001.png");
            if (sprite) {
                sprite->setScale(0.55f);
                auto button = CCMenuItemSpriteExtra::create(sprite, this, menu_selector(GDControlMenuLayer::onGDControl));
                button->setID("gdcontrol-open-button"_spr);
                menu->addChild(button);
                menu->updateLayout();
            }
        }
        return true;
    }

    void onGDControl(CCObject*) {
        gdcontrol::cycleMode();
        std::string status;
        switch (gdcontrol::mode) {
            case gdcontrol::Mode::Idle: status = "Idle. Tap the GD Control icon to record a new macro or play the saved one."; break;
            case gdcontrol::Mode::Recording: status = "RECORDING. Enter a level and play normally. Tap the GD Control icon again to save."; break;
            case gdcontrol::Mode::Playing: status = "PLAYBACK ARMED. Enter a level to replay the saved macro. Tap the icon to stop."; break;
        }
        FLAlertLayer::create("GD Control", status.c_str(), "OK")->show();
    }
};

class $modify(GDControlPlayLayer, PlayLayer) {
    void update(float dt) {
        PlayLayer::update(dt);
        using namespace gdcontrol;
        if (mode == Mode::Idle) return;
        if (mode == Mode::Recording) {
            ++frame;
            return;
        }
        if (mode == Mode::Playing) {
            ++frame;
            while (nextEvent < events.size() && events[nextEvent].frame <= frame) {
                auto const e = events[nextEvent++];
                replaying = true;
                if (e.down) this->pushButton(static_cast<PlayerButton>(e.button), e.player1, e.dual);
                else this->releaseButton(static_cast<PlayerButton>(e.button), e.player1, e.dual);
                replaying = false;
            }
            if (nextEvent >= events.size()) {
                mode = Mode::Idle;
                Notification::create("GD Control: playback finished", NotificationIcon::Success)->show();
            }
        }
        (void)dt;
    }

    void pushButton(PlayerButton button, bool player1, bool dual) {
        using namespace gdcontrol;
        if (mode == Mode::Recording && !replaying) {
            events.push_back(Event{frame, static_cast<int>(button), true, player1, dual});
        }
        PlayLayer::pushButton(button, player1, dual);
    }

    void releaseButton(PlayerButton button, bool player1, bool dual) {
        using namespace gdcontrol;
        if (mode == Mode::Recording && !replaying) {
            events.push_back(Event{frame, static_cast<int>(button), false, player1, dual});
        }
        PlayLayer::releaseButton(button, player1, dual);
    }

    void resetLevel() {
        using namespace gdcontrol;
        PlayLayer::resetLevel();
        if (mode == Mode::Playing) {
            frame = 0;
            nextEvent = 0;
        } else if (mode == Mode::Recording) {
            frame = 0;
            events.clear();
        }
    }

    void onQuit() {
        if (gdcontrol::mode == gdcontrol::Mode::Recording) gdcontrol::stop();
        else if (gdcontrol::mode == gdcontrol::Mode::Playing) gdcontrol::stop();
        PlayLayer::onQuit();
    }
};

$execute {
    log::info("GD Control loaded. Macro file: {}", gdcontrol::macroPath().string());
}
