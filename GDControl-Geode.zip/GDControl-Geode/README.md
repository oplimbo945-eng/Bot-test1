# GD Control — Geode mod 0.2.0

A native Geode mod prototype targeting Geometry Dash 2.2081. It adds a button to the main menu and an experimental frame-indexed macro recorder/player.

## Current prototype behavior
- Tap the GD Control button on the main menu to cycle through Idle → Recording → stop/save → playback armed.
- During a level, recording stores button down/up events with a frame index in `last-macro.gdc` under this mod's save directory.
- Playback replays the saved button events when entering a level; reset restarts playback.
- The format is a simple private CSV-like text format, not GDR/GDR2.

## Important limitations
This is an experimental prototype, not a verified xdBot replacement. The code has **not been compiled against the Geode SDK or tested on device in this environment**. In particular, verify the `PlayLayer::pushButton`/`releaseButton` hook signatures against the exact Geode SDK bindings before using it. Playback determinism depends on game speed, physics, refresh rate, and the level; no automatic level solver is implemented yet. A genuine automatic solver needs a gameplay state model and separate validation.

## Build
Use the official Geode SDK workflow with GitHub Actions: push this directory to a GitHub repository, then open Actions → Build GD Control. Download the `.geode` artifact from a successful run. If the build action's SDK selector changes, follow the current `geode-sdk/example-mod` template.

## Basic use (after successful build)
1. Install the resulting `.geode` package with Geode.
2. Open Geometry Dash and tap the GD Control icon in the main menu to begin recording.
3. Enter a level and play; return/quit the level to stop and save.
4. Tap the icon again to arm playback, then enter the same level.
5. Tap the icon to stop playback.

Please test only on a copy of your setup and keep backups. This is early-stage code and should not be considered bug-free.
