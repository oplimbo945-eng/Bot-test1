# Architecture

- `MenuLayer` adds a button to the existing bottom menu; its callback controls the prototype state machine.
- `PlayLayer::update` advances a frame counter and schedules due macro events.
- `pushButton` and `releaseButton` hooks capture input edges during recording and pass events through to the original game implementation.
- Macro files are stored in the Geode mod save directory as `last-macro.gdc`.

## State machine

`Idle -> Recording -> Idle` (stop saves) and `Idle -> Playing -> Idle` (events exhausted or stopped). Resetting a level restarts playback from frame 0 and clears the current recording if recording.

## Known engineering work before calling this stable

1. Build against exact SDK bindings and fix any signature differences.
2. Add explicit event versioning, bounds checks, validation and atomic file writes.
3. Handle death, level restart, pause, practice checkpoints, dual mode and speed changes consistently.
4. Add a proper in-game control panel and import/export UI.
5. Add unit tests for parser, event ordering and state transitions.
6. Design automatic play separately; replay is not an automatic solver.
